from django.db import models

class Coffee(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='coffee_images/', null=True, blank=True)
    score = models.IntegerField(default=0)

    def __str__(self):
        return self.name
