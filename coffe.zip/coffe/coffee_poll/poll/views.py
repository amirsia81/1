from django.shortcuts import render, get_object_or_404, redirect
from .models import Coffee
from django.http import HttpResponse

# صفحه اصلی
def index(request):
    coffees = Coffee.objects.all()
    return render(request, 'poll/index.html', {'coffees': coffees})

# صفحه رأی دادن به قهوه
def vote(request, coffee_id):
    coffee = get_object_or_404(Coffee, pk=coffee_id)

    if request.method == "POST":
        try:
            score = int(request.POST.get('score', 0))  # گرفتن مقدار و تبدیل به int
            coffee.score += score
            coffee.save()
            return redirect('results')
        except (ValueError, TypeError):
            return HttpResponse("Invalid score. Please enter a valid number.", status=400)

    return render(request, 'poll/vote.html', {'coffee': coffee})

# صفحه نمایش نتایج
def results(request):
    coffees = Coffee.objects.all().order_by('-score')
    return render(request, 'poll/results.html', {'coffees': coffees})
