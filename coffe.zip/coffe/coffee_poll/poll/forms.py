from django import forms

class VoteForm(forms.Form):
    score = forms.IntegerField(min_value=1, max_value=10, label='Your Score (1-10)')
